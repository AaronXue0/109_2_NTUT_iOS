//
//  pagesApp.swift
//  pages
//
//  Created by p on 2021/5/3.
//

import SwiftUI

@main
struct pagesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
