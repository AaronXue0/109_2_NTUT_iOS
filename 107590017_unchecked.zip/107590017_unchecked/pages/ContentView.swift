//
//  ContentView.swift
//  pages
//
//  Created by p on 2021/5/3.
//

import SwiftUI





struct ContentView: View {
    @State private var showSecondPage = false
    @State private var showSecondPage2 = false
    var body: some View {
        VStack{
            Text("澳洲水龍").font(.largeTitle)
            Image("picture").resizable().frame(width: 300, height: 300, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
        Button(action: {showSecondPage = true}, label: {
            Text("基本簡介")
        })
        .sheet(isPresented: $showSecondPage,  content:
                {SecondView(showSecondPage: $showSecondPage)
                })
        Button(action: {showSecondPage2 = true}, label: {
            Text("飼養守則")
        })
        .sheet(isPresented: $showSecondPage2,  content:
                {SecondView2(showSecondPage2: $showSecondPage2)
                })
        }
    }
  
       
        
}

struct SecondView: View{
    @Binding var showSecondPage: Bool
    let word = ["生長於澳大利亞","鱗目鬣蜥","60-90cm"]
    var body: some View{
        HStack{}.overlay(Button(action: {showSecondPage = false}, label: {
            Text("<Back").font(.largeTitle)
        }),alignment: .topLeading)
        VStack{
            
            ForEach(0..<3)
            {
                index in
                Text(word[index])
            }
            
        }
        
    }
}
struct SecondView2: View{
    @Binding var showSecondPage2: Bool
    let word = ["餵食蟋蟀,蟑螂,小白鼠","溫度控制25-28","濕度控制70-90%"]
    var body: some View{
        VStack{
            ForEach(0..<3)
            {
                index in
                Text(word[index])
            }
        }
        VStack{}.overlay(Button(action: {showSecondPage2 = false}, label: {
            Text("<Back").font(.largeTitle)
        }),alignment: .topLeading)

        
    }
}

struct DemoView: View{
    var body: some View{
        VStack
        {
            
        }
    }
    
    

    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
