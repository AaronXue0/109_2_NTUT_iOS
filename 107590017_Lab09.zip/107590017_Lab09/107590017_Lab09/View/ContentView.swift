//
//  ContentView.swift
//  107590017_Lab09
//
//  Created by Aaron Xue on 2021/5/19.
//

import SwiftUI

struct ContentView: View {
    @StateObject var gameViewModel = GameViewModel()
    
    var body: some View {
        VStack{
            Text("猜拳遊戲")
            HStack{
                Text("玩家: ")
                Image("\(gameViewModel.player ?? "")").resizable()
                    .frame(width: 32.0, height: 32.0)
            }.padding(-10)
            HStack{
                Text("電腦: ")
                Image("\(gameViewModel.ai ?? "")").resizable()
                    .frame(width: 32.0, height: 32.0)
            }.padding(-10)
            HStack{
                Image("paperscissorstone").resizable()
                    .frame(width: 70.0, height: 70.0)
            }
            if(gameViewModel.result == .draw){
                Text("Draw")
            }else {
                Text(gameViewModel.result == .win ? "Win" : "Lose" )
            }
            HStack{
                Button(action: {
                    gameViewModel.play()
                }, label: {
                    Text("Play")
                })
            }
        }
        .font(.largeTitle)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
