//
//  View.swift
//  107590017_Lab09
//
//  Created by Aaron Xue on 2021/5/19.
//

import Foundation
import SwiftUI

struct GameView: View {
    
    @StateObject var gameViewModel = GameViewModel()
    
    var body: some View {
        VStack{
            Text("猜拳遊戲")
            HStack{
                Text("玩家: ")
                Image("\(gameViewModel.gameModel?.playerResult.rawValue ?? "")")
            }
            HStack{
                Text("電腦: ")
                Image("\(gameViewModel.gameModel?.aiResult.rawValue ?? "")")
            }
            Text(gameViewModel.gameJudge() == .win ? "Win 🥳 " : "Lose 😢" )
            .font(.system(size: 100))
            Button(action: {
                gameViewModel.play()
            }, label: {
                Text("Play")
            })
        }
        .font(.largeTitle)
    }
}

struct GameView_Previews: PreviewProvider {
    static var previews: some View {
        GameView()
    }
}
