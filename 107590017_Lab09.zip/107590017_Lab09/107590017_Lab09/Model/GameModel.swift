//
//  Model.swift
//  107590017_Lab09
//
//  Created by Aaron Xue on 2021/5/19.
//

import Foundation

struct GameModel {
    var playerResult : PSS = PSS.paper
    var aiResult: PSS = PSS.paper
    
    enum PSS : String, CaseIterable  {
        case paper = "✋"
        case sesior = "✌️"
        case stone = "✊"
    }
    
    mutating func playerRandom(){
        playerResult = PSS.allCases.randomElement()!
    }
    
    mutating func aiRandom(){
        aiResult = PSS.allCases.randomElement()!
    }
}
