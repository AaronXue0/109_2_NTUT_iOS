//
//  ViewModel.swift
//  107590017_Lab09
//
//  Created by Aaron Xue on 2021/5/19.
//

import Foundation

class GameViewModel: ObservableObject{
    @Published var gameModel : GameModel?
    @Published var player : String? = ""
    @Published var ai : String? = ""
    @Published var result : GameResult?
    
    func play(){
        result = gameJudge()
    }
    
    func gameJudge() -> GameResult {
        let pss = ["✋","✌️","✊"]
        ai = pss.randomElement()
        player = pss.randomElement()
        if(ai == "✋" && player == "✌️"){
            return .win
        }
        else if(ai == "✋" && player == "✊"){
            return .lose
        }
        else if(ai == "✌️" && player == "✋"){
            return .lose
        }
        else if(ai == "✌️" && player == "✊"){
            return .win
        }
        else if(ai == "✊" && player == "✌️"){
            return .lose
        }
        else if(ai == "✊" && player == "✋"){
            return .win
        }else {
            return .draw
        }
    }
}
