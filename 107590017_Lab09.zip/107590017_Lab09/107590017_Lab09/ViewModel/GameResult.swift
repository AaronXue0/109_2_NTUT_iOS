//
//  GameREsult.swift
//  107590017_Lab09
//
//  Created by Aaron Xue on 2021/5/19.
//

import Foundation

enum GameResult : String{
    case win = "🥳"
    case lose = "😢"
    case draw = ""
}
